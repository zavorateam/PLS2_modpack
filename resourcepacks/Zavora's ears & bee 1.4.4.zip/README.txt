Hello! Thank you for downloading my pack!

If you're using this for personal use, enjoy!

If you're using this in a video, photo, or anything else, please credit me 
(becca4leafclover) by putting my name in the description of the first time 
these assets appear! Or if you have another way of crediting, that works too!

It is recommended for my packs that you use a texture pack to make item frames
invisible, and a texture pack to remove the pumpkinblur texture from carved
pumpkins. 

You have permission to edit the assets in this pack and combine them with other
packs, as long as credit is given.

Hope these help with whatever project you're using them for! -Becca

------------------------

ITEM - "NAME" NO QUOTES IN GAME

------------------------

carved pumpkin - "Orange Cat Ears"
carved pumpkin - "Black Cat Ears"
carved pumpkin - "White Cat Ears"
carved pumpkin - "Cream Cat Ears"